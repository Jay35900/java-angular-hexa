package com.doctor.spring.doctor.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctor.spring.doctor.model.Appointment;
import com.doctor.spring.doctor.repository.AppointmentRepository;


@Service
public class AppointmentService {

	@Autowired
	private AppointmentRepository appointmentRepository;
	
	public List<Appointment> fetchAllAppointments() {
		 
		return appointmentRepository.fetchAllAppointments();
	}
	public void softDelete(String cid) {
		appointmentRepository.softDelete(Integer.parseInt(cid));
		
	}
}
