package com.doctor.spring.doctor.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.doctor.spring.doctor.model.Appointment;


@Repository
public class AppointmentRepository {
	
	@Autowired
	private JdbcTemplate jdbc;
	
	public List<Appointment> fetchAllAppointments(){
		String sql = "SELECT id, name, Email_id, contact FROM appointment WHERE is_active = ?";
		PreparedStatementCreator psc= new PreparedStatementCreator() {
			
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement pstmt =con.prepareStatement(sql);
				pstmt.setBoolean(1, true);
				return pstmt;
			}
		};
		
		RowMapper<Appointment> rowMapper= new RowMapper<Appointment>() {

			@Override
			public Appointment mapRow(ResultSet rs, int rowNum) throws SQLException {
				Appointment appointment = new Appointment();
				int appointmentId=rs.getInt("id");
				String appointmentName = rs.getString("name");
				String appointmentemailid = rs.getString("Email_id");
				double appointmentcontact = rs.getDouble("contact");
				
				appointment.setId(appointmentId);
				appointment.setName(appointmentName);
				appointment.setEmail_id(appointmentemailid);
				appointment.setContact(appointmentcontact);
				
				return appointment;
			}
			
		};
		List <Appointment> list = jdbc.query(psc, rowMapper);
		 
		return list;	
	}
	public void softDelete(int cid) {
		String sql="update appointment set is_active=false where id=?";
		PreparedStatementCreator psc = new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement pstmt =  con.prepareStatement(sql);
				pstmt.setInt(1, cid);
				return pstmt;
			}
			
		};
		jdbc.update(psc);
	}
}
