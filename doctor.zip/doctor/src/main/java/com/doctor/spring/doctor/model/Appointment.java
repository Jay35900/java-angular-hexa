package com.doctor.spring.doctor.model;

public class Appointment {
	private int id; 
	private String name; 
	private String Email_id;
	private Double contact;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail_id() {
		return Email_id;
	}
	public void setEmail_id(String email_id) {
		Email_id = email_id;
	}
	public Double getContact() {
		return contact;
	}
	public void setContact(Double contact) {
		this.contact = contact;
	}
	
}
