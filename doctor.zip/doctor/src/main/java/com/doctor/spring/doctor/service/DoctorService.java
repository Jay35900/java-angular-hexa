package com.doctor.spring.doctor.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.doctor.spring.doctor.exception.InvalidCredentialsException;
import com.doctor.spring.doctor.model.User;
import com.doctor.spring.doctor.repository.DoctorRepository;

@Service
public class DoctorService {
	@Autowired
	private DoctorRepository doctorRepository;

public User verifyLogin(String username, String password) throws InvalidCredentialsException {
		
		return doctorRepository.verifyLogin(username,password);
	}
}