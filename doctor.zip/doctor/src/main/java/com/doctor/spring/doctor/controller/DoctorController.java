package com.doctor.spring.doctor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.doctor.spring.doctor.exception.InvalidCredentialsException;
import com.doctor.spring.doctor.model.Appointment;
import com.doctor.spring.doctor.model.User;
import com.doctor.spring.doctor.service.AppointmentService;
import com.doctor.spring.doctor.service.DoctorService;


import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class DoctorController {

	@Autowired
	private DoctorService doctorService; //DI
	
	@Autowired
	private AppointmentService appointmentService;
	

	@GetMapping("/")
	public String showLogin() {
		return "login";
	}
	
	@GetMapping("/login-form")
	public String handleLogin(HttpServletRequest req, HttpSession session) {
	    String username = req.getParameter("username");
	    String password = req.getParameter("password");
	    try {
	        // Use the injected doctorService instead of creating a new instance
	        User user = doctorService.verifyLogin(username, password);
	        
	        if (user != null && user.getRole().equalsIgnoreCase("doctor")) {
	            req.setAttribute("username", username);
	            session.setAttribute("username", username);
	            
	            List<Appointment> appointments = appointmentService.fetchAllAppointments();
	            req.setAttribute("listAppointments", appointments);
	            return "doctor_dashboard";
	        } else {
	            req.setAttribute("msg", "Unauthorized access or invalid role");
	            return "login";
	        }
	    } catch (InvalidCredentialsException e) {
	        req.setAttribute("msg", e.getMessage());
	        return "login";
	    }
	}

		@GetMapping("/doctor-dashboard")
		public String goToDoctorDashboard(HttpServletRequest req,HttpSession session) {
		List<Appointment> appointments= appointmentService.fetchAllAppointments();
		req.setAttribute("listAppointments", appointments);
		return "student_dashboard";

	}
		@GetMapping("/delete-appointment")
		public String deleteAppointment(HttpServletRequest req) {
			String cid = req.getParameter("cid");
			appointmentService.softDelete(cid);
			return "redirect:/doctor-dashboard";
		}
	
}